-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: activosfijos
-- ------------------------------------------------------
-- Server version	5.7.10-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activofijo`
--
CREATE Database activosfijos;

USE activosfijos;

DROP TABLE IF EXISTS `activofijo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activofijo` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Pk de la tabla. Es el identificador propio de la Tabla "Activo"',
  `nombre` varchar(45) DEFAULT NULL COMMENT 'Corresponde al nombre dle activo Fijo',
  `descripcion` varchar(100) DEFAULT NULL COMMENT 'Descripción del activo fijo',
  `codigoTipoActivo` int(11) DEFAULT NULL COMMENT 'Es la clave que relaciona a la tabla "Tipo" del activo Fijo',
  `serial` varchar(45) DEFAULT NULL COMMENT 'Serial único del Activo Fijo',
  `numeroInternoInventario` varchar(45) DEFAULT NULL COMMENT 'Corresponde al número interno de inventario del activo Fijo',
  `peso` decimal(10,0) DEFAULT NULL COMMENT 'Peso del Activo',
  `alto` decimal(10,0) DEFAULT NULL COMMENT 'Altura del activo fijo',
  `ancho` decimal(10,0) DEFAULT NULL COMMENT 'Medición de la anchura del Activo fijo',
  `largo` decimal(10,0) DEFAULT NULL COMMENT 'Almacena la información de medida de longitud del activo',
  `valorCompra` decimal(10,0) DEFAULT NULL COMMENT 'Corresponde al precio de Compra del activo fijo',
  `fechaCompra` datetime DEFAULT NULL COMMENT 'Fecha en la cual fue comprado el activo fijo',
  `fechaBaja` datetime DEFAULT NULL COMMENT 'Fecha en la que se dió de baja o se suspendión el activo fijo',
  `codigoEstadoActual` int(11) DEFAULT NULL COMMENT 'Es la clave que relaciona al estado actual del activo dijo',
  `color` varchar(45) DEFAULT NULL COMMENT 'Almacena el color del activo fijo',
  `codigoArea` int(11) DEFAULT NULL COMMENT 'Clave que relaciona el área a la que pertenece el activo Fijo',
  PRIMARY KEY (`codigo`),
  UNIQUE KEY `codigo_UNIQUE` (`codigo`),
  KEY `FK_activoFijo_TipoActivo_idx` (`codigoTipoActivo`),
  KEY `FK_activoFijo_EstadoActivoFijo_idx` (`codigoEstadoActual`),
  CONSTRAINT `FK_activoFijo_EstadoActivoFijo` FOREIGN KEY (`codigoEstadoActual`) REFERENCES `estadoactivofijo` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_activoFijo_TipoActivo` FOREIGN KEY (`codigoTipoActivo`) REFERENCES `tipoactivofijo` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activofijo`
--

LOCK TABLES `activofijo` WRITE;
/*!40000 ALTER TABLE `activofijo` DISABLE KEYS */;
INSERT INTO `activofijo` VALUES (1,'Rebanadora','Cortadora versátil con cuchillas circulares de 200',2,'M000001','1000000000',100,2,2,2,5000000,'2000-12-31 23:59:59','2017-01-31 23:59:59',2,'Gris',1),(2,'Edificio AV chile','Edificio Financiero AV Chile',1,'M000002','1000000001',100000,30,6,28,2000000,'2012-12-31 23:59:59','2017-02-05 23:59:59',1,'Cafe',3),(3,'Casa alterna','CAsa blanca Avenida siempre Viva',1,'M000003','1000000002',23400,6,7,12,2000000,'2012-12-31 23:59:59','2012-12-31 23:59:59',1,'Blanca',3),(4,'Apartamento Nuevo','Lugar de hospedaje',2,'M000002','1000000003',100,2,2,2,5000000,'2000-12-30 00:00:00','2017-01-30 00:00:00',2,'Gris',1),(5,'Apartamento Nuevo','Lugar de hospedaje',2,'M000004','1000000003',100,2,2,2,5000000,'2000-12-30 00:00:00','2017-01-30 00:00:00',5,'Gris',1);
/*!40000 ALTER TABLE `activofijo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area`
--

DROP TABLE IF EXISTS `area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area` (
  `codigo` int(10) unsigned NOT NULL COMMENT 'Clave - llave primaria de la tabla',
  `nombre` varchar(45) DEFAULT NULL,
  `codigoCiudad` int(11) DEFAULT NULL,
  PRIMARY KEY (`codigo`),
  UNIQUE KEY `codigo_UNIQUE` (`codigo`),
  KEY `FK_area_ciudad_idx` (`codigoCiudad`),
  CONSTRAINT `FK_area_ciudad` FOREIGN KEY (`codigoCiudad`) REFERENCES `ciudad` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area`
--

LOCK TABLES `area` WRITE;
/*!40000 ALTER TABLE `area` DISABLE KEYS */;
INSERT INTO `area` VALUES (1,'Producción',1),(2,'Ensamblaje',2),(3,'Administracion',3);
/*!40000 ALTER TABLE `area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ciudad`
--

DROP TABLE IF EXISTS `ciudad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ciudad` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Clave  - Llave primaria de la tabla ''Ciudad''',
  `nombre` varchar(45) DEFAULT NULL COMMENT 'Nombre de la Ciudad',
  PRIMARY KEY (`codigo`),
  UNIQUE KEY `codigo_UNIQUE` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ciudad`
--

LOCK TABLES `ciudad` WRITE;
/*!40000 ALTER TABLE `ciudad` DISABLE KEYS */;
INSERT INTO `ciudad` VALUES (1,'Medellin'),(2,'Bogotá'),(3,'Cali'),(4,'Barranquilla');
/*!40000 ALTER TABLE `ciudad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estadoactivofijo`
--

DROP TABLE IF EXISTS `estadoactivofijo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estadoactivofijo` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Clave - llave primaria de la tabla ''EstadoActivoFijo''',
  `nombre` varchar(45) DEFAULT NULL COMMENT 'Nombre del estado que puede tener un activo fijo',
  `descripcion` varchar(100) DEFAULT NULL COMMENT 'Descripción del estado actual de un activo fijo',
  PRIMARY KEY (`codigo`),
  UNIQUE KEY `codigo_UNIQUE` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estadoactivofijo`
--

LOCK TABLES `estadoactivofijo` WRITE;
/*!40000 ALTER TABLE `estadoactivofijo` DISABLE KEYS */;
INSERT INTO `estadoactivofijo` VALUES (1,'Activo','Activo'),(2,'Dado de baja','Dado de baja'),(3,'En reparación','En reparación'),(4,'Disponible','Disponible'),(5,'Asignado','Asignado');
/*!40000 ALTER TABLE `estadoactivofijo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipoactivofijo`
--

DROP TABLE IF EXISTS `tipoactivofijo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipoactivofijo` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Clave única - llave primaria de la Tabla ''TipoActivo''',
  `nombre` varchar(45) DEFAULT NULL COMMENT 'Nombre del tipo de activo fijo',
  `descripcion` varchar(100) DEFAULT NULL COMMENT 'Descripción del tipo de activo fijo',
  PRIMARY KEY (`codigo`),
  UNIQUE KEY `codigo_UNIQUE` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipoactivofijo`
--

LOCK TABLES `tipoactivofijo` WRITE;
/*!40000 ALTER TABLE `tipoactivofijo` DISABLE KEYS */;
INSERT INTO `tipoactivofijo` VALUES (1,'Bien inmueble','Bien inmueble'),(2,'Maquinari','Maquinari'),(3,'Material de Oficina','Material de Oficina');
/*!40000 ALTER TABLE `tipoactivofijo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-02-24  0:55:03
